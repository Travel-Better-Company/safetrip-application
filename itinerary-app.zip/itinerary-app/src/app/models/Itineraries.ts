// itineraries.model.ts
export interface Itineraries {
  name: string;
  ini_date: string;
  end_date: string;
  userId: number;
  cityId: number;
}