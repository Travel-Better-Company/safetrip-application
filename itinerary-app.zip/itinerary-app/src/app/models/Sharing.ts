export interface Sharing {
    id_user_origin: number,    
    id_user_target:number,
    id_itinerary:number,
    text:string
}