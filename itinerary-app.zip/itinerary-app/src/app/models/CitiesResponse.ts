export interface CitiesResponse {
    id:number,
    name:string,
    sights:string[]
}