// activities.model.ts

export interface Activities {
  name: string;
  iniDate: string;
  startTime: string;
  endTime: string;
  id_itinerary: number;
}