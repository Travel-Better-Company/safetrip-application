import { Component } from '@angular/core';

@Component({
  selector: 'app-activity-view',
  templateUrl: './activity-view.component.html',
  styleUrl: './activity-view.component.css'
})
export class ActivityViewComponent {

}
