import { Component } from '@angular/core';

@Component({
  selector: 'app-register-activity',
  templateUrl: './register-activity.component.html',
  styleUrl: './register-activity.component.css'
})
export class RegisterActivityComponent {

}
