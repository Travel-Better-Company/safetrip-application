import { Component } from '@angular/core';

@Component({
  selector: 'app-register-itinerary',
  templateUrl: './register-itinerary.component.html',
  styleUrl: './register-itinerary.component.css'
})
export class RegisterItineraryComponent {

}
