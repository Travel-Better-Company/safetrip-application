import { Component } from '@angular/core';

@Component({
  selector: 'app-itinerary-view',
  templateUrl: './itinerary-view.component.html',
  styleUrl: './itinerary-view.component.css'
})
export class ItineraryViewComponent {

}
